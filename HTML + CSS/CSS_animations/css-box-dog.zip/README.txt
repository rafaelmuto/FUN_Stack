A Pen created at CodePen.io. You can find this one at https://codepen.io/agathaco/pen/eLOKvr.

 I did my best at recreating this awesome animation by Tony Babel with CSS only. Original: https://dribbble.com/shots/4934623-Box-Doggie

Also this pen by David Khourshid https://codepen.io/davidkpiano/pen/Xempjq helped me figure out the tail animation