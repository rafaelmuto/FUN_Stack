// Original animation by Tony Babel
// https://dribbble.com/shots/4934623-Box-Doggie
"use strict";