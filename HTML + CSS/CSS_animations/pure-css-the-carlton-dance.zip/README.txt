A Pen created at CodePen.io. You can find this one at https://codepen.io/Wujek_Greg/pen/EpJwaj.

 Simple animation of the Cartlon dance