A Pen created at CodePen.io. You can find this one at https://codepen.io/pgalor/pen/YjbxmW.

 Pure CSS animated scene in 3D. 